A Pen created at CodePen.io. You can find this one at http://codepen.io/garris/pen/Lcrbl.

 TremulaJS is a responsive Javascript content carousel/slider with Bézier-based momentum & physics effects for mouse, trackpad and touch devices. 

This Pen allows you to experiment using different config file settings.